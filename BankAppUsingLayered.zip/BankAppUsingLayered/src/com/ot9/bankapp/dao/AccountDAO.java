package com.ot9.bankapp.dao;

import java.util.Set;

import com.ot9.bankapp.dto.Account;
import com.ot9.bankapp.dto.Transaction;
import com.ot9.bankapp.exceptions.InsufficientBalance;

public interface AccountDAO {
	public abstract String createAccount(Account account);

	public abstract float withdrawAmount(int accountNo, float amountToWithdraw) throws InsufficientBalance;

	public abstract float depositAmount(int accountNo, float amountToDeposit) throws InsufficientBalance;

	public abstract float fundTransfer(int fromaccountNo, int toaccountNo, float amountToTransfer)
			throws InsufficientBalance;

	public abstract Set<Transaction> printTransactions();

	public abstract Account viewAccountDetails(int accountNo);

}
