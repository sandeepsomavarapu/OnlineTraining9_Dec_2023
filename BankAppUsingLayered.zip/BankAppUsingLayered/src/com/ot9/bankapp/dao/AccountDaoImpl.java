package com.ot9.bankapp.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.ot9.bankapp.dto.Account;
import com.ot9.bankapp.dto.Transaction;
import com.ot9.bankapp.exceptions.InsufficientBalance;

public class AccountDaoImpl implements AccountDAO {
	HashMap<Integer, Account> accounts = new HashMap<Integer, Account>();// database
	HashMap<Integer, Transaction> transactions = new HashMap<Integer, Transaction>();// database
	int transactionId = 1000;

	@Override
	public String createAccount(Account account) {
		accounts.put(account.getAccountNo(), account);
		return "Account Created Successfully With Acc No: " + account.getAccountNo();
	}

	@Override
	public float withdrawAmount(int accountNo, float amountToWithdraw) throws InsufficientBalance {
		Account accountDetails = accounts.get(accountNo);
		float exsisitngBalance = accountDetails.getAccountBalnce();
		float updatedBalance;
		if (exsisitngBalance > amountToWithdraw) {
			updatedBalance = exsisitngBalance - amountToWithdraw;
			accountDetails.setAccountBalnce(updatedBalance);
			Transaction transaction = new Transaction(++transactionId, "withdraw", updatedBalance, accountNo, 0,
					new Date());
			transactions.put(transactionId, transaction);
			return updatedBalance;
		} else {
			throw new InsufficientBalance("Not Enount Funds");
		}
	}

	@Override
	public float depositAmount(int accountNo, float amountToDeposit) throws InsufficientBalance {
		Account accountDetails = accounts.get(accountNo);
		float exsisitngBalance = accountDetails.getAccountBalnce();
		float updatedBalance;
		if (exsisitngBalance > amountToDeposit) {
			updatedBalance = exsisitngBalance + amountToDeposit;
			accountDetails.setAccountBalnce(updatedBalance);
			Transaction transaction = new Transaction(++transactionId, "withdraw", updatedBalance, accountNo, 0,
					new Date());
			transactions.put(transactionId, transaction);
			return updatedBalance;
		} else {
			throw new InsufficientBalance("Not Enount Funds");
		}
	}

	@Override
	public float fundTransfer(int fromAccountNo, int toAccountNo, float amountToTransfer) throws InsufficientBalance {
		Account fromAccountDetails = accounts.get(fromAccountNo);
		float fromAccountBalance = fromAccountDetails.getAccountBalnce();
		if (fromAccountBalance > amountToTransfer) {
			Account toAccountDetails = accounts.get(toAccountNo);
			float toAccountBalance = toAccountDetails.getAccountBalnce();

			float updatedFromAccountBalance = fromAccountBalance - amountToTransfer;
			fromAccountDetails.setAccountBalnce(updatedFromAccountBalance);
			accounts.put(fromAccountNo, fromAccountDetails);
			float updatedToAccountBalance = toAccountBalance + amountToTransfer;
			toAccountDetails.setAccountBalnce(updatedToAccountBalance);
			accounts.put(toAccountNo, toAccountDetails);
			Transaction transaction2 = new Transaction(++transactionId, "fundtransfer", updatedFromAccountBalance,
					fromAccountNo, toAccountNo, new Date());
			transactions.put(transactionId, transaction2);
			return updatedFromAccountBalance;
		} else {
			throw new InsufficientBalance("Not Enount Funds");
		}
	}

	@Override
	public Set<Transaction> printTransactions() {
		Set<Integer> set = transactions.keySet();
		Iterator<Integer> itr = set.iterator();
		Set<Transaction> trans = new HashSet<Transaction>();
		while (itr.hasNext()) {
			int transId = itr.next();
			trans.add(transactions.get(transId));

		}
		return trans;
	}

	@Override
	public Account viewAccountDetails(int accountNo) {

		return accounts.get(accountNo);
	}

}
