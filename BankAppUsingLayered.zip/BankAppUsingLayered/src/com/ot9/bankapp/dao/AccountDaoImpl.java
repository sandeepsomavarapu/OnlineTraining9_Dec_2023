package com.ot9.bankapp.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.ot9.bankapp.dto.Account;
import com.ot9.bankapp.dto.Transaction;
import com.ot9.bankapp.exceptions.InsufficientBalance;
import com.ot9.bankapp.exceptions.InvalidAccountNo;

public class AccountDaoImpl implements AccountDAO {
	HashMap<Integer, Account> accounts = new HashMap<Integer, Account>();// database
	HashMap<Integer, Transaction> transactions = new HashMap<Integer, Transaction>();// database
	int transactionId = 1000;

	@Override
	public String createAccount(Account account) {
		accounts.put(account.getAccountNo(), account);
		return "Account Created Successfully With Acc No: " + account.getAccountNo();
	}

	@Override
	public float withdrawAmount(int accountNo, float amountToWithdraw) throws InsufficientBalance, InvalidAccountNo {
		Account accountDetails = accounts.get(accountNo);
		if (accountDetails != null) {
			float exsisitngBalance = accountDetails.getAccountBalnce();
			float updatedBalance;
			if (exsisitngBalance > amountToWithdraw) {
				updatedBalance = exsisitngBalance - amountToWithdraw;
				accountDetails.setAccountBalnce(updatedBalance);
				Transaction transaction = new Transaction(++transactionId, "withdraw", updatedBalance, accountNo, 0,
						new Date());
				transactions.put(transactionId, transaction);
				return updatedBalance;
			} else {
				throw new InsufficientBalance("Not Enount Funds");
			}
		} else {
			throw new InvalidAccountNo("Wrong account no try again with correct accno...");
		}
	}

	@Override
	public float depositAmount(int accountNo, float amountToDeposit) throws InvalidAccountNo {
		Account accountDetails = accounts.get(accountNo);
		if (accountDetails != null) {
			float exsisitngBalance = accountDetails.getAccountBalnce();
			float updatedBalance;

			updatedBalance = exsisitngBalance + amountToDeposit;
			accountDetails.setAccountBalnce(updatedBalance);
			Transaction transaction = new Transaction(++transactionId, "withdraw", updatedBalance, accountNo, 0,
					new Date());
			transactions.put(transactionId, transaction);
			return updatedBalance;

		} else {
			throw new InvalidAccountNo("wrong account number...");
		}
	}

	@Override
	public float fundTransfer(int fromAccountNo, int toAccountNo, float amountToTransfer)
			throws InsufficientBalance, InvalidAccountNo {
		Account fromAccountDetails = accounts.get(fromAccountNo);
		Account toAccountDetails = accounts.get(toAccountNo);

		if (fromAccountDetails != null && toAccountDetails != null) {
			float fromAccountBalance = fromAccountDetails.getAccountBalnce();
			float toAccountBalance = toAccountDetails.getAccountBalnce();
			if (fromAccountBalance > amountToTransfer) {
				float updatedFromAccountBalance = fromAccountBalance - amountToTransfer;
				fromAccountDetails.setAccountBalnce(updatedFromAccountBalance);
				accounts.put(fromAccountNo, fromAccountDetails);
				float updatedToAccountBalance = toAccountBalance + amountToTransfer;
				toAccountDetails.setAccountBalnce(updatedToAccountBalance);
				accounts.put(toAccountNo, toAccountDetails);
				Transaction transaction2 = new Transaction(++transactionId, "fundtransfer", updatedFromAccountBalance,
						fromAccountNo, toAccountNo, new Date());
				transactions.put(transactionId, transaction2);
				return updatedFromAccountBalance;
			} else {
				throw new InsufficientBalance("Not Enount Funds");
			}
		} else {
			throw new InvalidAccountNo("invalid account numnber");
		}
	}

	@Override
	public Set<Transaction> printTransactions() {
		Set<Integer> set = transactions.keySet();
		Iterator<Integer> itr = set.iterator();
		Set<Transaction> trans = new HashSet<Transaction>();
		while (itr.hasNext()) {
			int transId = itr.next();
			trans.add(transactions.get(transId));

		}
		return trans;
	}

	@Override
	public Account viewAccountDetails(int accountNo) {

		return accounts.get(accountNo);
	}

}
