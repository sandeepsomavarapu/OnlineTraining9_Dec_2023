package com.ot9.bankapp.dto;

import java.util.Date;

public class Transaction {
	private int transactionId;
	private String transactionType;
	private float balance;
	private int fromAccount;
	private int toAcoount;
	private Date dateOfTransaction;

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public int getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(int fromAccount) {
		this.fromAccount = fromAccount;
	}

	public int getToAcoount() {
		return toAcoount;
	}

	public void setToAcoount(int toAcoount) {
		this.toAcoount = toAcoount;
	}

	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}

	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}

	@Override
	public String toString() {
		return "transactionId=" + transactionId + ", transactionType=" + transactionType + ", balance="
				+ balance + ", fromAccount=" + fromAccount + ", toAcoount=" + toAcoount + ", dateOfTransaction="
				+ dateOfTransaction ;
	}

	public Transaction() {
		// TODO Auto-generated constructor stub
	}

	public Transaction(int transactionId, String transactionType, float balance, int fromAccount, int toAcoount,
			Date dateOfTransaction) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.balance = balance;
		this.fromAccount = fromAccount;
		this.toAcoount = toAcoount;
		this.dateOfTransaction = dateOfTransaction;
	}

}
