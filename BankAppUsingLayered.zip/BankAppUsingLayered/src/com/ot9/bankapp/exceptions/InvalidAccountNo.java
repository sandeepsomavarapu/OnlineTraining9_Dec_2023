package com.ot9.bankapp.exceptions;

public class InvalidAccountNo extends Exception {

	public InvalidAccountNo(String message) {
		super(message);
	}
}
