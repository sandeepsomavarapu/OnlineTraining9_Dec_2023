package com.ot9.bankapp.service;

import java.util.Set;

import com.ot9.bankapp.dto.Account;
import com.ot9.bankapp.dto.Transaction;
import com.ot9.bankapp.exceptions.InsufficientBalance;
import com.ot9.bankapp.exceptions.InvalidAccountNo;

public interface AccountService {
	public abstract String createAccount(Account account);

	public abstract float withdrawAmount(int accountNo, float amountToWithdraw) throws InsufficientBalance, InvalidAccountNo;

	public abstract float depositAmount(int accountNo, float amountToDeposit) throws  InvalidAccountNo;

	public abstract float fundTransfer(int fromaccountNo, int toaccountNo, float amountToTransfer) throws InsufficientBalance, InvalidAccountNo;

	public abstract Set<Transaction> printTransactions();

	public abstract Account viewAccountDetails(int accountNo);
}
