package com.ot9.bankapp.service;

import java.util.Set;

import com.ot9.bankapp.dao.AccountDAO;
import com.ot9.bankapp.dao.AccountDaoImpl;
import com.ot9.bankapp.dto.Account;
import com.ot9.bankapp.dto.Transaction;
import com.ot9.bankapp.exceptions.InsufficientBalance;
import com.ot9.bankapp.exceptions.InvalidAccountNo;

public class AccountServiceImpl implements AccountService {
	AccountDAO dao = new AccountDaoImpl();

	@Override
	public String createAccount(Account account) {

		return dao.createAccount(account);
	}

	@Override
	public float withdrawAmount(int accountNo, float amountToWithdraw) throws InsufficientBalance, InvalidAccountNo {

		return dao.withdrawAmount(accountNo, amountToWithdraw);
	}

	@Override
	public float depositAmount(int accountNo, float amountToDeposit) throws  InvalidAccountNo {

		return dao.depositAmount(accountNo, amountToDeposit);
	}

	@Override
	public float fundTransfer(int fromaccountNo, int toaccountNo, float amountToTransfer) throws InsufficientBalance, InvalidAccountNo {

		return dao.fundTransfer(fromaccountNo, toaccountNo, amountToTransfer);
	}

	@Override
	public Set<Transaction> printTransactions() {
		return dao.printTransactions();
	}

	@Override
	public Account viewAccountDetails(int accountNo) {

		return dao.viewAccountDetails(accountNo);
	}

}
