package com.ot9.bankapp.ui;

import java.util.Scanner;
import java.util.Set;

import com.ot9.bankapp.dto.Account;
import com.ot9.bankapp.dto.Transaction;
import com.ot9.bankapp.exceptions.InsufficientBalance;
import com.ot9.bankapp.exceptions.InvalidAccountNo;
import com.ot9.bankapp.service.AccountService;
import com.ot9.bankapp.service.AccountServiceImpl;

public class BankClient {

	public static void main(String[] args) {// collections
		AccountService service = new AccountServiceImpl();
		int accountNo;
		String accountHolderName;
		float accountBalnce;
		String accountBranch;
		long contact;

		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("**************Bank Application************");
			System.out.println("1)Create Account");
			System.out.println("2)View Account Details");
			System.out.println("3)Withdraw");
			System.out.println("4)Deposit");
			System.out.println("5)FundTransfer");
			System.out.println("6)Print Transactions ");
			System.out.println("7)Exit");
			int option = scan.nextInt();// ui code

			switch (option) {
			case 1:

				System.out.println("Enter Details To Create Account :");
				System.out.println("Enter Your Name ");
				accountHolderName = scan.next();
				System.out.println("Enter Your Amount ");
				accountBalnce = scan.nextFloat();
				System.out.println("Enter Your Branch ");
				accountBranch = scan.next();
				System.out.println("Enter Your Contact ");
				contact = scan.nextLong();
				accountNo = (int) (contact - 100000);
				Account account = new Account(accountNo, accountHolderName, accountBalnce, accountBranch, contact);
				System.out.println(service.createAccount(account));
				break;
			case 2:
				System.out.println("Enter You Account No:");
				accountNo = scan.nextInt();
				System.out.println("Account Details :" + service.viewAccountDetails(accountNo));
				break;
			case 3:
				System.out.println("Enter You Account No to withdraw:");
				accountNo = scan.nextInt();
				System.out.println("Enter Your Amount ");
				float amountToWithdraw = scan.nextFloat();

				try {
					System.out.println(
							"Updated Balance After Withdraw : " + service.withdrawAmount(accountNo, amountToWithdraw));
				} catch (InsufficientBalance e) {
					System.out.println("Not Enough Balance To Withdraw");
				} catch (InvalidAccountNo e) {
					System.out.println("Enter valid Account Number...");
				}
				break;
			case 4:
				System.out.println("Enter You Account No to Deposit:");
				accountNo = scan.nextInt();
				System.out.println("Enter Your Amount ");
				float amountToDeposit = scan.nextFloat();
				try {
					System.out.println(
							"Updated Balance after Deposit: " + service.depositAmount(accountNo, amountToDeposit));
				} catch (InvalidAccountNo e) {
					System.out.println("Enter valid Account Number...");
				}

				break;
			case 5:
				System.out.println("Enter From Account No for Transfer:");
				int fromAccountNo = scan.nextInt();
				System.out.println("Enter To Account No for Transfer:");
				int toAccountNo = scan.nextInt();
				System.out.println("Enter Your Amount to transfer ");
				float amountToTransfer = scan.nextFloat();
				try {
					System.out.println("updated balance after fundtransfer :"
							+ service.fundTransfer(fromAccountNo, toAccountNo, amountToTransfer));
				} catch (InsufficientBalance e) {
					System.out.println("Not Enough Balance To Withdraw");
				} catch (InvalidAccountNo e) {
					System.out.println("Enter valid Account Number...");
				}
				break;
			case 6:
				Set<Transaction> transactions = service.printTransactions();
				for (Transaction trans : transactions) {
					System.out.println(trans);
				}

				break;
			case 7:
				scan.close();
				System.out.println("Thank You !!!");
				System.exit(0);
				break;
			}
		}

	}

}
